package taggame;

public class Controller {

    Display display = new Display();
    Player player;
    Room startRoom;                 //RUM 1
    Room hallRoom;                  //RUM 2
    Room livingRoom;                //RUM 3
    Room libaryRoom;                //RUM 4
    Room labatoryRoom;              //RUM 5
    Room diningRoom;                //RUM 6
    Room kitchenRoom;               //RUM 7
    Room officeRoom;                //RUM 8
    Room therapyRoom;               //RUM 9
    Room hallwayRoom;               //RUM 10
    Room corridorRoom;              //RUM 11
    Room corridorRoom1;             //RUM 12
    Room basementEntranceRoom;      //RUM 13
    Room prisonCellRoom;            //RUM 14
    Room prisonCellRoom1;           //RUM 15
    Room weaponRoom;                //RUM 16
    Room tortureRoom;               //RUM 17
    Room treasureRoom;              //RUM 18
    Room bossRoom;                  //RUM 19    
    Room endRoom;                   //RUM 21

    public void start() throws InterruptedException {
        createRoom();
        player = new Player(display.nameInput(), 100);
        player.setLocation(startRoom);
        display.welcomeMessage();
        display.letsStart();
        System.out.println(player.getLocation().getDescription());

        while (true) {
            playerControl();
        }
    }

    private void nextRoom(String way) throws InterruptedException {
        Room room = player.getLocation();
        switch (way) {
            case "north":
                if (room.getNorth() != null) {
                    player.setLocation(player.getLocation().getNorth());
                    display.transitText();
                    System.out.println(player.getLocation().getDescription());
                } else {
                    System.out.println("There is no door!");
                }
                break;
            case "south":
                if (room.getSouth() != null) {
                    player.setLocation(player.getLocation().getSouth());
                    display.transitText();
                    System.out.println(player.getLocation().getDescription());
                } else {
                    System.out.println("There is no door!");
                }
                break;
            case "east":
                if (room.getEast() != null) {
                    player.setLocation(player.getLocation().getEast());
                    display.transitText();
                    System.out.println(player.getLocation().getDescription());
                } else {
                    System.out.println("There is no door!");
                }
                break;
            case "west":
                if (room.getWest() != null) {
                    player.setLocation(player.getLocation().getWest());
                    display.transitText();
                    System.out.println(player.getLocation().getDescription());
                } else {
                    System.out.println("There is no door!");
                }
                break;
        }
    }

    public void playerControl() throws InterruptedException {
        switch (display.playerInput()) {
            case "north":
            case "n":
                nextRoom("north");
                break;
            case "south":
            case "s":
                nextRoom("south");
                break;
            case "east":
            case "e":
                nextRoom("east");
                break;
            case "west":
            case "w":
                nextRoom("west");
                break;
            case "help":
            case "h":
                display.helpInput();
                break;
            case "exit":
            case "quit":
                display.Exit();
        }
    }

    public void createRoom() {
        //Rum 1
        startRoom = new Room("\nYou wake up with a set! You quickly get yourself standing, and look around."
                + "\nWhere are you? What happend last night?"
                + "\nSlowly you remember walking down the dark path leading to the house, and that you ran in fear."
                + "\nCould this be that very mansion that you find yourself in?"
                + "\n"
                + "\nThis room seems like an entrance, it has no objects or furniture, "
                + "\nexcept a enormous carpet leading to a door east from you");
        //Rum 2
        hallRoom = new Room("\nYou are in large hallway, there is a statue to your left, its shiny like it has been polished recently."
                + "\nThere is nothing else in this room, you see a door that goes south and east.");
        //Rum 3
        livingRoom = new Room("\nYou enter to a giant living room. There is a candle on the table, it seems to just have been put out,"
                + "\nthe smoke is still rising from it. There is four doors in here, the one to you're left is wide open.");
        //Rum 4
        libaryRoom = new Room("\nIts a small room, all the walls are covered with bookshelfs. You notice a book, laying open"
                + "\nin the middle of the room. This room is a dead end.");
        //Rum 5
        labatoryRoom = new Room("\nYou are greeted by a terrible chemical smell, there is 3 tables in the middle formed as a U."
                + "\nIt's a labatory, there is a big flask with a red liqiud in it. The room is a dead end");
        //Rum 6
        kitchenRoom = new Room("\nYou enter a small kitchen, there is huge cauldrons with food in it. The smell of the food comforts you,"
                + "\nand you get a little hungry. There is no way to know if that food is healthy or not, it could be risky to eat."
                + "\nThere is one door leading south.");
        //Rum 7
        diningRoom = new Room("\nYou set food into a giant dining room. There is one long table in the middle, with only one chair at "
                + "\nthe very end. It seems like someone just ate here. The chair has been pushed away from the table, like if someone"
                + "\n has been in a hurry. There is door out of the room both east and west.");
        //Rum 8
        officeRoom = new Room("Right as enter you see a office table right infront of you. There is a big leather chair behind the table,"
                + "\n and a small chair on the other side. It seems to have been where who ever owns this place, talk to patients."
                + "\nThere is another door on the south and north side of the room.");
        //Rum 9
        therapyRoom = new Room("Its a small cozy room, the is a couch with a chair next to it. Maybe this is where he held his therapy meetins"
                + "\nThere is a door going east.");
        //Rum 10
        hallwayRoom = new Room("There is nothing in here, but a staircase going down, to your right. You look down the staircase"
                + "\nand see a door at the end. There is no where to go but down there or back.");
        //Rum 11
        corridorRoom = new Room("");
        //Rum 12
        corridorRoom1 = new Room("");
        //Rum 13
        basementEntranceRoom = new Room("");
        //Rum 14
        prisonCellRoom = new Room("");
        //Rum 15
        prisonCellRoom1 = new Room("");
        //Rum 16
        weaponRoom = new Room("");
        //Rum 17
        tortureRoom = new Room("");
        //Rum 18     
        treasureRoom = new Room("");
        //Rum 19   
        bossRoom = new Room("");
        //Rum 20
        endRoom = new Room("");

        //Rum 1
        startRoom.setNorth(null);
        startRoom.setSouth(null);
        startRoom.setEast(hallRoom);
        startRoom.setWest(null);
        //Rum 2  
        hallRoom.setNorth(null);
        hallRoom.setSouth(livingRoom);
        hallRoom.setEast(kitchenRoom);
        hallRoom.setWest(null);
        //Rum 3
        livingRoom.setNorth(hallRoom);
        livingRoom.setSouth(labatoryRoom);
        livingRoom.setEast(diningRoom);
        livingRoom.setWest(libaryRoom);
        //Rum 4
        libaryRoom.setNorth(null);
        libaryRoom.setSouth(null);
        libaryRoom.setEast(livingRoom);
        libaryRoom.setWest(null);
        //Rum 5
        labatoryRoom.setNorth(livingRoom);
        labatoryRoom.setSouth(null);
        labatoryRoom.setEast(null);
        labatoryRoom.setWest(null);
        //Rum 6
        kitchenRoom.setNorth(null);
        kitchenRoom.setSouth(diningRoom);
        kitchenRoom.setEast(null);
        kitchenRoom.setWest(hallRoom);
        //Rum 7
        diningRoom.setNorth(kitchenRoom);
        diningRoom.setEast(officeRoom);
        diningRoom.setWest(livingRoom);
        //Rum 8
        officeRoom.setNorth(therapyRoom);
        officeRoom.setSouth(corridorRoom);
        //Rum 9
        therapyRoom.setSouth(officeRoom);
        therapyRoom.setEast(hallwayRoom);
        //Rum 10
        hallwayRoom.setSouth(corridorRoom);
        hallwayRoom.setWest(therapyRoom);
        //Rum 11
        corridorRoom.setNorth(hallwayRoom);
        corridorRoom.setEast(corridorRoom1);
        corridorRoom.setWest(officeRoom);
        //Rum 12
        corridorRoom1.setNorth(basementEntranceRoom);
        corridorRoom1.setWest(corridorRoom);
        //Rum 13
        basementEntranceRoom.setNorth(weaponRoom);
        basementEntranceRoom.setSouth(corridorRoom1);
        basementEntranceRoom.setWest(tortureRoom);
        //Rum 14
        prisonCellRoom.setSouth(weaponRoom);
        //Rum 15
        prisonCellRoom1.setSouth(treasureRoom);
        //Rum 16
        weaponRoom.setNorth(prisonCellRoom);
        weaponRoom.setSouth(basementEntranceRoom);
        weaponRoom.setWest(treasureRoom);
        //Rum 17
        tortureRoom.setNorth(treasureRoom);
        tortureRoom.setSouth(bossRoom);
        tortureRoom.setWest(basementEntranceRoom);
        //Rum 18
        treasureRoom.setNorth(prisonCellRoom1);
        treasureRoom.setSouth(tortureRoom);
        treasureRoom.setEast(weaponRoom);
        treasureRoom.setWest(endRoom);
        //Rum 19
        bossRoom.setNorth(tortureRoom);
        //Rum20

    }

}
