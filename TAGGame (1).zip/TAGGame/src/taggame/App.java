
package taggame;


public class App {

    
    public static void main(String[] args) throws InterruptedException {
        Controller con = new Controller();
        con.start();
    }
    
}
